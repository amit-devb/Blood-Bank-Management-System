<?php defined('BASEPATH') OR exit ('No direct script aceess allowed');

class Bloodbank extends CI_Controller{

 public function __construct(){

    parent:: __construct();
    
    $this->load->view('header.php');
    $this->load->view('footer.php');
    $this->load->helper(array('form', 'url'));
    $this->load->library('form_validation');
    $this->load->model('model_receiver');
    
    
    
  }

  public function index(){
    
    $this->load->view('home.php');

    
 
  }
  
  
}
