<?php defined('BASEPATH') OR exit ('No direct script aceess allowed');

Class Hospital extends CI_Controller{

    function __construct(){

        parent:: __construct();
        $this->load->view('header1.php');
        $this->load->view('hospitalheader.php');
        $this->load->view('footer.php');
        $this->load->helper(array('form', 'url'));
        $this->load->library('form_validation');
        $this->load->model('model_hospital');
       
        
      }
    public function index(){
      
      
    }
    public function addHospital(){
        
        $this->load->view('hospitalRegister'); 
      }
    

    public function hospitalRegister(){
        if(isset($_POST['hospitalSubmit'])){
          $this->form_validation->set_rules('hospitalName','Name','required|alpha');  
          $this->form_validation->set_rules('hospitalEmail','Email','trim|required|valid_email|is_unique[hospitalregister.hospitalEmail]');
          $this->form_validation->set_rules('hospitalPassword','Password','required','trim|required|min_length[8]|');
          $this->form_validation->set_rules('hospitalContact','Contact','required');
          $this->form_validation->set_rules('hospitalAddress','Address','required');
          $this->form_validation->set_error_delimiters('<div class="error">', '</div>');
          if($this->form_validation->run()==TRUE){
            //echo 'ok';
            $this->model_hospital->register(); 
            $this->load->view('hospitalSuccessForm');
          }
          else{
            $this->load->view('hospitalRegister');
          }
        }
    }
    //Login View
    public function hospital_login(){

        $this->load->view('hospitalLogin');
    }

    //Hospital Login Function
    public function hospitalLogin(){

        if(isset($_POST['hospital_Login'])){
        
          $this->form_validation->set_rules('hospital_email','Email','trim|required|valid_email');
          $this->form_validation->set_rules('hospital_password','Password','required');  
          $this->form_validation->set_error_delimiters('<div class="error">', '</div>');
    
          if($this->form_validation->run()==TRUE){
            $username  = $this->input->post('hospital_email');
            $password  = $this->input->post('hospital_password');
            $login_id  = $this->model_hospital->authHospital($username,$password); 
            if($login_id){
              $this->load->library('session');
              $this->session->set_userdata('hospital_name',$login_id); 
        
              //$this->load->view('receiver');   
               return redirect('Hospital/user_home');     
            }
            else{
              $this->session->set_flashdata('login_failed','Username/Password Invalid');
              return redirect('Hospital/hospital_login'); 
              
              
            }
            
            
          }
    
          else
          {
            $this->load->view('hospitalLogin');
          }
        }
         
    }
    public function user_home(){
      if(! $this->session->userdata('hospital_name')){
        return redirect('Hospital/hospital_login'); 
      }
      //$this->load->view('hospital');
      $data['items'] = $this->model_hospital->getItems();                   //Loading the model in the index function and calling the getItems function from the model.
      $this->load->view("hospital",$data);   
      //$field['requests'] = $this->model_hospital->getRequest();                   //Loading the model in the index function and calling the getItems function from the model.
      //$this->load->view("hospital",$field);   
       
      
    }
    //Logout for Hospital
    public function hospitalLogout(){
      $this->session->unset_userdata('hospital_name');
      $this->load->view('hospitalLogin');
    
    }
    //Add Blood
    public function addBlood(){
        if(! $this->session->userdata('hospital_name')){
            return redirect('Hospital/hospital_login'); 
          }
        $this->load->view('addblood');
    }
    //Function for Blood Addition
    public function bloodSubmit(){
       
        if(isset($_POST['bloodSubmit'])){
           
            
        $this->model_hospital->blood_submit();
            
               
        } 
    }
    //Requestion Blood sample
    public function request(){
      if(! $this->session->userdata('hospital_name')){
        return redirect('Hospital/hospital_login'); 
      }
      $field['requests'] = $this->model_hospital->getRequest();                   //Loading the model in the index function and calling the getItems function from the model.
      $this->load->view("request",$field);   
    }
   
    
    
    
}

