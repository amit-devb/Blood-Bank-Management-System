<?php defined('BASEPATH') OR exit ('No direct script aceess allowed');

Class Receiver extends CI_Controller{

    function __construct(){

        parent:: __construct();

        
    $this->load->view('header1.php');
    $this->load->view('receiverheader.php');
    $this->load->view('footer.php');
    $this->load->helper(array('form', 'url'));
    $this->load->library('form_validation');
    $this->load->model('model_receiver');
       
        
      }

    public function index(){
       // $this->load->view('home.php');
       $q['sample'] = $this->model_receiver->getsamples() ;                //Loading the model in the index function and calling the getItems function from the model.
       $this->load->view("receiver",$q);   
    }

    public function addReceiver(){

        $this->load->view('receiverRegister'); 
      }
    
      public function receiverRegister(){
        
        
        if(isset($_POST['receiverSubmit'])){
          $this->form_validation->set_rules('receiverName','Name','required|alpha');  
          $this->form_validation->set_rules('receiverEmail','Email','trim|required|valid_email|is_unique[receiverRegster.receiverEmail]');
          $this->form_validation->set_rules('receiverPassword','Password','required','trim|required|min_length[8]|');
          $this->form_validation->set_rules('receiverContact','Contact','required');
          $this->form_validation->set_rules('receiverAddress','Address','required');
          $this->form_validation->set_rules('receiverBloodgroup','Blood Group','required');
          $this->form_validation->set_error_delimiters('<div class="error">', '</div>');
          if($this->form_validation->run()==TRUE){
            //$this->load->view('receiverSuccessForm');
            $this->model_receiver->register(); 
            $this->load->view('receiverSuccessForm');
          }
          else{
            $this->load->view('receiverRegister');
          }
        }
       
          
       
      }
      public function receiver_login(){
    
        $this->load->view('receiverLogin');
      }
      public function receiverLogin(){
    
        if(isset($_POST['receiver_Login'])){
        
          $this->form_validation->set_rules('receiver_email','Email','trim|required');
          $this->form_validation->set_rules('receiver_password','Password','required');  
          $this->form_validation->set_error_delimiters('<div class="error">', '</div>');
    
          if($this->form_validation->run()==TRUE){
    
            $username  = $this->input->post('receiver_email');
            $password  = $this->input->post('receiver_password');
            $login_id  = $this->model_receiver->authReceiver($username,$password); 
            if($login_id){
              $this->load->library('session');
              $this->session->set_userdata('user_name',$login_id); 
              $this->load->view('receiver');   
               return redirect('Receiver/user_home');     
            }
            else{
              $this->session->set_flashdata('login_failed','Username/Password Invalid');
              return redirect('Receiver/receiver_login'); 
              
              
            }
          
            
            
          }
    
          else
          {
            $this->load->view('receiverLogin');
          }
        }
         
    }
    public function user_home(){
      if(! $this->session->userdata('user_name')){
        return redirect('Receiver/receiver_login'); 
      }
      //$data['items'] = $this->model_hospital->getSamples();                   //Loading the model in the index function and calling the getItems function from the model.
       
      //$this->load->view('receiver'); 
      $data['items'] = $this->model_receiver->getItems();                   //Loading the model in the index function and calling the getItems function from the model.
      $this->load->view("receiver",$data); 
      
    }
    
    public function receiverLogout(){
      $this->session->unset_userdata('user_name');
      $this->load->view('receiverLogin');
    
    }
    public function requestSample(){
      if(! $this->session->userdata('user_name')){
        return redirect('Receiver/receiver_login'); 
      }
      $this->load->view('requestsample.php');
    }
    public function request(){
        
        
      if(isset($_POST['requestSubmit'])){
        
        $this->form_validation->set_rules('email','Email','trim|required');
        $this->form_validation->set_rules('name','Name','required|alpha');  
        
        $this->form_validation->set_rules('contact','Contact','required');
        $this->form_validation->set_rules('address','Address','required');
        $this->form_validation->set_rules('bloodgroup','Blood Group','required');
        $this->form_validation->set_rules('hospitalname','Hospital Name','required');

        $this->form_validation->set_error_delimiters('<div class="error">', '</div>');
        if($this->form_validation->run()==TRUE){
          //$this->load->view('receiverSuccessForm');
          $this->model_receiver->request_sample(); 
          $this->load->view('requestsuccess');
        }
        else{
          $this->load->view('requestfail');
        }
      }
     
        
     
    }
    
    
}

