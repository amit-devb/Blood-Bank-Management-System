<?php defined('BASEPATH') OR exit ('No direct script aceess allowed');

class Model_hospital extends CI_Model{

    public function index(){
        echo 'ok';
    }

    public function register(){
        
        $field = array(
            'hospitalId'         => NULL,
            'hospitalName'       => $this->input->post('hospitalName'),
            'hospitalEmail'      => $this->input->post('hospitalEmail'),
            'hospitalPassword'   => $this->input->post('hospitalPassword'),
            'hospitalContact'    => $this->input->post('hospitalContact'),
            'hospitalAddress'    => $this->input->post('hospitalAddress'),
            
          );
          $this->db->insert('hospitalregister',$field);
     
   }

   public function authHospital($username,$password){
    $query = $this->db->get_where('hospitalregister', array('hospitalEmail ' => $username,'hospitalPassword' => $password));
    return $query->row();
   }

   public function blood_submit(){
    $data = array(
        'bloodId'         => NULL,
        'bloodGroup'      => $this->input->post('bloodGroup'),
        'bloodUnit '      => $this->input->post('bloodUnit'),
        'hospital_name'   => $this->input->post('hospital_name')
        
        
        
      );
      $this->db->insert('addBlood',$data);
   }    

   public function getItems(){
    $query = $this->db->get('addBlood');
    if($query->num_rows() > 0)
    {
     return $query->result();
    }
    else
    {
     return false;
    }
  }

  public function getRequest(){
    $query = $this->db->get('request');
    if($query->num_rows() > 0)
    {
     return $query->result();
    }
    else
    {
     return false;
    } 
  }
}