<?php defined('BASEPATH') OR exit ('No direct script aceess allowed');

class Model_receiver extends CI_Model{

    public function index(){
        echo 'ok';
    }

    public function register(){
        
        $field = array(
            'receiverId'         => NULL,
            'receiverName'       => $this->input->post('receiverName'),
            'receiverEmail'      => $this->input->post('receiverEmail'),
            'receiverPassword'   => $this->input->post('receiverPassword'),
            'receiverBloodgroup' => $this->input->post('receiverBloodgroup'),
            'receiverContact'    => $this->input->post('receiverContact'),
            'receiverAddress'    => $this->input->post('receiverAddress'),
            
          );
          $this->db->insert('receiverRegster',$field);
     
   }

   public function authReceiver($username,$password){
    $query = $this->db->get_where('receiverRegster', array('receiverEmail ' => $username,'receiverPassword' => $password));
    return $query->row();
   }

   public function getItems(){
    $query = $this->db->get('addBlood');
    if($query->num_rows() > 0)
    {
     return $query->result();
    }
    else
    {
     return false;
    }
  }
  public function request_sample(){
        
    $field = array(
        'requestId'         => NULL,
        'name'              => $this->input->post('name'),
        'email'             => $this->input->post('email'),
        'bloodgroup'        => $this->input->post('bloodgroup'),
        'contact'           => $this->input->post('contact'),
        'address'           => $this->input->post('address'),
        'hospitalname'      => $this->input->post('hospitalname')
        
      );
      $this->db->insert('request',$field);
 
}
    
}