<div class="col-md-3"></div>
<div class="container col-md-6">
<div class="panel-group">
    <div class="panel panel-success">  
    <div class="panel-heading">Please Fill In The Details</div> 
        <div class="panel-body">
            
            <form action="bloodSubmit" method="POST">
            <div class="form-group">
                <label for="">Blood Group</label>
                <input type="text" class="form-control" id="bloodGroup" name="bloodGroup" placeholder="Eg: O+, O-, B+, B-" value="<?php echo set_value('bloodGroup'); ?>" >
                <?php echo form_error('bloodGroup', '<div class="error text-danger">', '</div>'); ?>
            </div>
            <div class="form-group">
                <label for="">Unit</label>
                <input type="text" class="form-control" id="bloodUnit" name="bloodUnit" placeholder="Enter Number OF Unit" value="<?php echo set_value('bloodUnit'); ?>" >
                <?php echo form_error('bloodUnit', '<div class="error text-danger">', '</div>'); ?>
            </div>
            
            <div class="form-group">
                <label for="">Hospital Name</label>
                <input type="text" class="form-control" id="hospital_name" name="hospital_name" placeholder="Enter Hospital Name" value="<?php echo set_value('hospital_name'); ?>" >
               
            </div>
            
            
            <div class="form-group">
               
                <input type="submit" class="btn btn-success btn-block" value="Submit" name="bloodSubmit">
            </div>
            </form>
        </div>
       
    </div>
     </div>  
</div>