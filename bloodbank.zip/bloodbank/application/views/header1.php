<!DOCTYPE html>
<html>
 <head>
   <title>Bloodshala</title>
   <meta charset="utf-8">
   <meta name="viewport" content="width=device-width, initial-scale=1">
   <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/css/bootstrap.min.css">
   <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.3.1/jquery.min.js"></script>
   <script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/js/bootstrap.min.js"></script>
   <link rel="stylesheet" href="assests/css/header.css">
   <script src="assests/js/home.js"></script>
   <style>
   /* navbar */
   .navbar-default {
  background-color:#990000;
  background-image: none;
  background-repeat: no-repeat;
  color: black;
 }
 .nav.navbar-nav.navbar-right li a {
    color: black;
    
}
.nav.navbar-nav.navbar li a {
    color: black;
    
}
.jumbotron {
  background-color:#990000;
  background-image: none;
  background-repeat: no-repeat;
  color: black;
 }

    </style>
  
 </head>
 <body>
  
  <div class="container">
    <!-- Bloodshala header-->
    <div class = "page-header text-center">
      <h1 style="color:#990000;">
          Bloodshala
          <small></small>
      </h1>
    </div><!--pageheader ends-->

   <!--Navbar Starts-->
    <nav class="navbar navbar-default nav-justified">
      <div class="container-fluid">
        <div class="navbar-header">
          <button type="button" class="navbar-toggle" data-toggle="collapse" data-target="#myNavbar">
            <span class="icon-bar"></span>
            <span class="icon-bar"></span>
            <span class="icon-bar"></span>                        
          </button>
          <a class="navbar-brand" href="#"></a>
        </div>
        <div class="collapse navbar-collapse" id="myNavbar">
          <ul class="nav navbar-nav">
            <li class="active"><a href="http://127.0.0.1/bloodbank/index.php/Bloodbank/">Home</a></li>
            <li class=""><a href="http://127.0.0.1/bloodbank/index.php/Receiver/user_home">Blood Bank</a></li>
            <li><a href="" data-toggle="modal" data-target="#aboutModal">About </a></li>
            <li><a href="" data-toggle="modal" data-target="#contactModal">Contact </a></li>
          </ul>
          <ul class="nav navbar-nav navbar-right">
            <li class="dropdown">
              <a class="dropdown-toggle" data-toggle="dropdown" href="#"> Receiver<span class="caret"></span></a>
              <ul class="dropdown-menu">
                
                <li><a href="http://localhost/bloodbank/index.php/Receiver/addReceiver"> Register</a></li>
                <li><a href="http://localhost/bloodbank/index.php/Receiver/receiver_login">Login</a></li>
              </ul>
            </li>
          </ul>
          <ul class="nav navbar-nav navbar-right">
          <li class="dropdown">
              <a class="dropdown-toggle" data-toggle="dropdown" href="#">Hospital <span class="caret"></span></a>
              <ul class="dropdown-menu">
                
                <li><a href="http://localhost/bloodbank/index.php/Hospital/addHospital">Register</a></li>
                <li><a href="http://localhost/bloodbank/index.php/Hospital/hospital_login">Login</a></li>
              </ul>
            </li>
          </ul>
        </div>
      </div>
    </nav><!--Navbar Ends-->

    
  

<!-- About Modal -->
<div id="aboutModal" class="modal fade" role="dialog">
  <div class="modal-dialog">

    <!-- Modal content-->
    <div class="modal-content">
      <div class="modal-header">
        <button type="button" class="close" data-dismiss="modal">&times;</button>
        <h4 class="modal-title">Bloodshala</h4>
      </div>
      <div class="modal-body">
        <div class="panel panel-primary">
        <div class="panel-heading">What We do</div>
        <div class="panel-body">
        <p>
          <p>Blood Online is a  web resource  platform designed to help patients and Hospitals to 
                avail blood to the needy because life is precious and we value time and life.</p>
        </p>
        </div>
    </div>
      </div>
      <div class="modal-footer">
        <button type="button" class="btn btn-default" data-dismiss="modal">Close</button>
      </div>
    </div>

  </div>
</div>


 <!-- Modal -->
 <div id="contactModal" class="modal fade" role="dialog">
  <div class="modal-dialog">

    <!-- Modal content-->
    <div class="modal-content">
      <div class="modal-header">
        <button type="button" class="close" data-dismiss="modal">&times;</button>
        <h4 class="modal-title">Bloodshala</h4>
      </div>
      <div class="modal-body">
      <div class="panel panel-primary">
      <div class="panel-heading">Reach Us</div>
      <div class="panel-body">
      <p>
      christian Basti, Silver Screen Building <br>
      Guwahati, Assam<br>
      India<br>
      Phone +1.202.857 900
      Fax // +1.202.887.5093
      Email: bloodshala.org
            </p>
      </div>
    </div>
      </div>
      <div class="modal-footer">
        <button type="button" class="btn btn-default" data-dismiss="modal">Close</button>
      </div>
    </div>

  </div>
</div>



      