
<div class="container">
  <h3>Collapsible Navbar</h3>
  <p>In this example, the navigation bar is hidden on small screens and replaced by a button in the top right corner (try to re-size this window).
  <p>Only when the button is clicked, the navigation bar will be displayed.</p>
</div>

<!--Receiver Register Modal-->

<!-- Receiver Login Modal-->



<!--Hospital Register Modal-->
<div id="receiverRegisterModal" class="modal fade" role="dialog">
  <div class="modal-dialog">

    <!-- Modal content-->
    <div class="modal-content">
      <div class="modal-header">
        <button type="button" class="close" data-dismiss="modal">&times;</button>
        <h4 class="modal-title">Hospital Register</h4>
      </div>
      <div class="modal-body">
         <form>
            <div class="form-group">
                <label for="">Name</label>
                <input type="text" class="form-control" id="hospitalName" placeholder="Enter Your Name">
            </div>
            <div class="form-group">
                <label for="">Email</label>
                <input type="email" class="form-control" id="hospitalEmail" placeholder="Enter Your Email">
            </div>
            <div class="form-group">
                <label for="">Password</label>
                <input type="text" class="form-control" id="hospitalPassword" placeholder="Enter your Password">
            </div>
            
            
            <div class="form-group">
                <label for="">Contact</label>
                <input type="text" class="form-control" id="hospitalContact" placeholder="Enter your Contact">
            </div>
            <div class="form-group">
                <label for="">Address</label>
                <input type="text" class="form-control" id="hospitalAddress" placeholder="Enter your Address">
            </div>
            
            <div class="form-group">
               
                <input type="submit" class="btn btn-success btn-block" value="Submit" name="hospitalSubmit">
            </div>
            
            
           
        </form>
      </div>
      <div class="modal-footer">
        <button type="button" class="btn btn-default" data-dismiss="modal">Close</button>
      </div>
    </div>

  </div>
</div> <!--Hospital Register Modal Ends-->

<!-- Hospital Login Modal-->

<div id="hospitalLoginModal" class="modal fade" role="dialog">
  <div class="modal-dialog">

    <!-- Modal content-->
    <div class="modal-content">
      <div class="modal-header">
        <button type="button" class="close" data-dismiss="modal">&times;</button>
        <h4 class="modal-title">Login</h4>
      </div>
      <div class="modal-body">
         <form>
            <div class="form-group">
                <label for="">Email</label>
                <input type="text" class="form-control" id="hospitalEmail" placeholder="Enter Your Email">
            </div>
            <div class="form-group">
                <label for="">Password</label>
                <input type="email" class="form-control" id="hospitalPassword" placeholder="Enter Your Password">
            </div>
            
            <div class="form-group">
               
                <input type="submit" class="btn btn-success btn-block" value="Submit" name="hospitalLogin">
            </div>
            
            
           
        </form>
      </div>
      <div class="modal-footer">
        <button type="button" class="btn btn-default" data-dismiss="modal">Close</button>
      </div>
    </div>

  </div>
</div> <!--Hospital Login Modal Ends-->


