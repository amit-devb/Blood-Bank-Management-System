


<br>
<!--Table start -->
<div class="col-md-2"></div>
<div class="container col-md-8">

<table class="table table-bordered table-responsive">
      <thead>
        <tr>
          <td>ID</td>
          <td>Blood Group</td>
          <td>Blood Unit</td>
          <td>Hospital Name</td>
          
        </tr>
      </thead>
      <tbody>
        <?php
          foreach($items as $row)
       {
         ?>
         <tr>
            <td><?php echo $row->bloodId;?></td>
            <td><?php echo $row->bloodGroup;?></td>
            <td><?php echo $row->bloodUnit;?></td>
            <td><?php echo $row->hospital_name;?></td>
           
            
        </tr>
        <?php
            }
        ?>
         </tbody>
    </table>
    </div>
        <br><br>

       