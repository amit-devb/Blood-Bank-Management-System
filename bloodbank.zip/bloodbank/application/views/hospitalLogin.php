<br><br>
<div class="col-md-3"></div>
<div class="container col-md-6">
  <div class="panel-group">
    <div class="panel panel-success">  
        <div class="panel-heading text-center">
            <h3 >Please Fill In The Details</h3>
        </div> 
            <div class="panel-body">
                <?php if($error = $this->session->flashdata('login_failed'));?>
                 <?php echo $error; ?> 
                 <form action="hospitalLogin" method="POST">
                    <div class="form-group">
                        <label for="">Email</label>
                        <input type="email" class="form-control" id="hospital_Email" name="hospital_email" placeholder="Enter Your Email" value="<?php echo set_value('hospital_email'); ?>">
                        <?php echo form_error('hospital_email', '<div class="error text-danger">', '</div>'); ?>
                    </div>
                    <div class="form-group">
                        <label for="">Password</label>
                        <input type="text" class="form-control" id="hospital_Password" name="hospital_password" placeholder="Enter Your Password" >
                        <?php echo form_error('receiver_password', '<div class="error text-danger">', '</div>'); ?>
                    </div>
                
                    <div class="form-group">
                        <input type="submit" class="btn btn-success btn-block" value="Submit" name="hospital_Login">
                    </div>  
                    
            
                </form>
            </div>
        </div>
    </div>
 </div>
</div>