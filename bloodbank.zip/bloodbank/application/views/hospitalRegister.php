

<div class="col-md-3"></div>
<div class="container col-md-6">
<div class="panel-group">
    <div class="panel panel-success">  
    <div class="panel-heading">Please Fill In The Details</div> 
        <div class="panel-body">
            
            <form action="hospitalRegister" method="POST">
            <div class="form-group">
                <label for="">Name</label>
                <input type="text" class="form-control" id="hospitalName" name="hospitalName" placeholder="Enter Your Name" value="<?php echo set_value('hospitalName'); ?>" >
                <?php echo form_error('hospitalName', '<div class="error text-danger">', '</div>'); ?>
            </div>
            <div class="form-group">
                <label for="">Email</label>
                <input type="email" class="form-control" id="hospitalEmail" name="hospitalEmail" placeholder="Enter Your Email" value="<?php echo set_value('hospitalEmail'); ?>" >
                <?php echo form_error('hospitalEmail', '<div class="error text-danger">', '</div>'); ?>
            </div>
            <div class="form-group">
                <label for="">Password</label>
                <input type="text" class="form-control" id="hospitalPassword" name="hospitalPassword" placeholder="Enter your Password" value="<?php echo set_value('hospitalPassword'); ?>" >
                <?php echo form_error('hospitalPassword', '<div class="error text-danger">', '</div>'); ?>
            </div>
            
           
            <div class="form-group">
                <label for="">Contact</label>
                <input type="text" class="form-control" id="hospitalContact" name="hospitalContact" placeholder="Enter your Contact" value="<?php echo set_value('hospitalContact'); ?>" >
                <?php echo form_error('hospitalContact', '<div class="error text-danger">', '</div>'); ?>
            </div>
            <div class="form-group">
                <label for="">Address</label>
                <input type="text" class="form-control" id="hospitalAddress" name="hospitalAddress" placeholder="Enter your Address" value="<?php echo set_value('hospitalAddress'); ?>" >
                <?php echo form_error('hospitalAddress', '<div class="error text-danger">', '</div>'); ?>
            </div>
            
            <div class="form-group">
               
                <input type="submit" class="btn btn-success btn-block" value="Submit" name="hospitalSubmit">
            </div>
            </form>
        </div>
       
    </div>
     </div>  
</div>