





<br>
<br>
    <div class="container">
  <ul class="nav nav-tabs nav-justified">
   
    <li><a href="addBlood" class="btn btn-warning">Add Blood</a></li>
    <li><a href="user_home" class="btn btn-warning">Blood Sample</a></li>
    <li><a href="http://127.0.0.1/bloodbank/index.php/Hospital/request" class="btn btn-danger">Request</a></li>
    <li><a href="hospitalLogout" class="btn btn-danger">Log Out</a></li>
    
  </ul>
</div><br>


      