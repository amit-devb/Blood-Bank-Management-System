
<div class="well text-center"><h1>Available Blood Sample</h1></div>

<div class="col-md-2"></div>
<div class="container col-md-8 text-center">
  <!--Table start -->
<table class="table table-bordered table-responsive">
      <thead>
        <tr>
          <td>ID</td>
          <td>Blood Group</td>
          <td>Blood Unit</td>
          <td>Hospital Name</td>
          <td>Action</td>
          
        </tr>
      </thead>
      <tbody>
        <?php
          foreach($items as $row)
       {
         ?>
         <tr>
            <td><?php echo $row->bloodId;?></td>
            <td><?php echo $row->bloodGroup;?></td>
            <td><?php echo $row->bloodUnit;?></td>
            <td><?php echo $row->hospital_name;?></td>
            <td><a href="http://127.0.0.1/bloodbank/index.php/Receiver/requestSample" class="btn btn-danger">Request Sample</a></td>
           
            
        </tr>
        <?php
            }
        ?>


      </tbody>
    </table>
    </div>