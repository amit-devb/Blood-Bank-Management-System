

<div class="col-md-3"></div>
<div class="container col-md-6">
<div class="panel-group">
    <div class="panel panel-success">  
    <div class="panel-heading">Please Fill In The Details</div> 
        <div class="panel-body">
            <?php if(isset($_SESSION['success'])){?>
              <div class="alert alert-success"><?php echo $_SESSION['success']; ?></div>
            <?php 
                }
            ?>
            <form action="receiverRegister" method="POST">
            <div class="form-group">
                <label for="">Name</label>
                <input type="text" class="form-control" id="receiverName" name="receiverName" placeholder="Enter Your Name" value="<?php echo set_value('receiverName'); ?>" >
                <?php echo form_error('receiverName', '<div class="error text-danger">', '</div>'); ?>
            </div>
            <div class="form-group">
                <label for="">Email</label>
                <input type="email" class="form-control" id="receiverEmail" name="receiverEmail" placeholder="Enter Your Email" value="<?php echo set_value('receiverEmail'); ?>" >
                <?php echo form_error('receiverEmail', '<div class="error text-danger">', '</div>'); ?>
            </div>
            <div class="form-group">
                <label for="">Password</label>
                <input type="text" class="form-control" id="receiverPassword" name="receiverPassword" placeholder="Enter your Password" value="<?php echo set_value('receiverPassword'); ?>" >
                <?php echo form_error('receiverPassword', '<div class="error text-danger">', '</div>'); ?>
            </div>
            
            <div class="form-group">
                <label for="">Blood Group</label>
                <input type="text" class="form-control" id="receiverBloodGroup" name="receiverBloodgroup" placeholder="Eg:-O+,O-,B+,B-,A+,A-" value="<?php echo set_value('receiverBloodgroup'); ?>" >
                <?php echo form_error('receiverBloodgroup', '<div class="error text-danger">', '</div>'); ?>
            </div>
            <div class="form-group">
                <label for="">Contact</label>
                <input type="text" class="form-control" id="receiverContact" name="receiverContact" placeholder="Enter your Contact" value="<?php echo set_value('receiverContact'); ?>" >
                <?php echo form_error('receiverContact', '<div class="error text-danger">', '</div>'); ?>
            </div>
            <div class="form-group">
                <label for="">Address</label>
                <input type="text" class="form-control" id="receiverAddress" name="receiverAddress" placeholder="Enter your Address" value="<?php echo set_value('receiverAddress'); ?>" >
                <?php echo form_error('receiverAddress', '<div class="error text-danger">', '</div>'); ?>
            </div>
            
            <div class="form-group">
               
                <input type="submit" class="btn btn-success btn-block" value="Submit" name="receiverSubmit">
            </div>
            </form>
        </div>
       
    </div>
     </div>  
</div>