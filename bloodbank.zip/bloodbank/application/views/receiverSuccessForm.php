





<div class="col-md-3"></div>
<div class="container col-md-6 text-success text-center">
  <h1>Your Registration Was Sucessfull. Please Log Into Your Account  </h1>
  <a href="http://localhost/bloodbank/index.php/Receiver/receiver_login"><button class="btn btn-primary btn-lg">Login</button></a>
</div>