





<br>
<br>
    <div class="container">
  <ul class="nav nav-tabs nav-justified">
   
    <li><a href="http://127.0.0.1/bloodbank/index.php/Receiver/user_home" class="btn btn-warning">Blood Sample</a></li>
    <li><a href="http://127.0.0.1/bloodbank/index.php/Receiver/requestSample" class="btn btn-warning">Request Sample</a></li>
    <li><a href="receiverLogout" class="btn btn-warning">Log Out</a></li>
    
  </ul>
</div><br>


      