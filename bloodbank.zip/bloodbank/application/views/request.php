

<div class="col-md-2"></div>
<div class="container col-md-8 text-center">
<h3>Blood Sample Request</h3>
  <!--Table start -->
<table class="table table-bordered table-responsive">
      <thead>
        <tr>
          <td>ID</td>
          <td>Email</td>
          <td>Name</td>
          <tdContact></td>
          <td>Address</td>
          <td>Blood Group</td>
          <td>Hospital Name</td>
          
        </tr>
      </thead>
      <tbody>
        <?php
          foreach($requests as $r)
       {
         ?>
         <tr>
            <td><?php echo $r->requestId;?></td>
            <td><?php echo $r->email;?></td>
            <td><?php echo $r->name;?></td>
            <td><?php echo $r->contact;?></td>
            <td><?php echo $r->address;?></td>
            <td><?php echo $r->bloodgroup;?></td>
            <td><?php echo $r->hospitalname;?></td>
            
            
        </tr>
        <?php
            }
        ?>


      </tbody>
    </table>
    </div>


     