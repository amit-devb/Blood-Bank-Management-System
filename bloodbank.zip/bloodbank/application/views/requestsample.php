<br><br>
<div class="col-md-3"></div>
<div class="container col-md-6">
  <div class="panel-group">
    <div class="panel panel-success">  
        <div class="panel-heading text-center">
            <h3 >Please Fill In The Request Details</h3>
        </div> 
            <div class="panel-body">
               
                 <form action="request" method="POST">
                    <div class="form-group">
                        <label for="">Email</label>
                        <input type="email" class="form-control" id="" name="email" placeholder="Enter Your Email" value="<?php echo set_value('email'); ?>">
                        <?php echo form_error('email', '<div class="error text-danger">', '</div>'); ?>
                    </div>
                    <div class="form-group">
                        <label for="">Name</label>
                        <input type="text" class="form-control" id="name" name="name" placeholder="Enter Your Name" value="<?php echo set_value('name'); ?>">
                        <?php echo form_error('name', '<div class="error text-danger">', '</div>'); ?>
                    </div>
                    <div class="form-group">
                        <label for="">Contact</label>
                        <input type="text" class="form-control" id="" name="contact" placeholder="Enter Your Contact" value="<?php echo set_value('contact'); ?>">
                        <?php echo form_error('contact', '<div class="error text-danger">', '</div>'); ?>
                    </div>
                    <div class="form-group">
                        <label for="">Address</label>
                        <input type="text" class="form-control" id="address" name="address" placeholder="Enter Your Address" value="<?php echo set_value('address'); ?>">
                        <?php echo form_error('', '<div class="error text-danger">', '</div>'); ?>

                    </div>
                    <div class="form-group">
                        <label for="">Blood Group</label>
                        <input type="text" class="form-control" id="bloodgroup" name="bloodgroup" placeholder="Enter Requested Blood Group" value="<?php echo set_value('bloodgroup'); ?>">
                        <?php echo form_error('bloodgroup', '<div class="error text-danger">', '</div>'); ?>
                    </div>
                    <div class="form-group">
                        <label for="">Hospital Name</label>
                        <input type="text" class="form-control" id="hospitalname" name="hospitalname" placeholder="Enter The Requested Hospital Name" value="<?php echo set_value('hospitalname'); ?>">
                        <?php echo form_error('hospitalname', '<div class="error text-danger">', '</div>'); ?>
                    </div>
                
                    <div class="form-group">
                        <input type="submit" class="btn btn-success btn-block" value="Submit" name="requestSubmit">
                    </div>  
                    
            
                </form>
            </div>
        </div>
    </div>
 </div>
</div>